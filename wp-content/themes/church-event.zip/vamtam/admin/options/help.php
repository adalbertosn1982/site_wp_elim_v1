<?php
return array(
	'name' => __('Help', 'church-event'),
	'auto' => true,
	'config' => array(

		array(
			'name' => __('Help', 'church-event'),
			'type' => 'title',
			'desc' => '',
		),

		array(
			'name' => __('Help', 'church-event'),
			'type' => 'start',
			'nosave' => true,
		),
//----
		array(
			'type' => 'docs',
		),

			array(
				'type' => 'end'
			),
		
	)
);