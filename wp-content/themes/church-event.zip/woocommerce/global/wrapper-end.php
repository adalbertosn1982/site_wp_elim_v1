<?php
/**
 * Content wrappers
 *
 * @author 		Vamtam
 * @package 	wpv
 * @subpackage  church-event
 * @version     2.1.0
 */

global $post;

?>
		</div>
	</article>
	<?php WpvTemplates::right_sidebar() ?>
</div>
