<?php
/**
 * Single page template
 *
 * Template Name: Blank
 *
 * @package wpv
 * @subpackage church-event
 */

get_template_part('page');