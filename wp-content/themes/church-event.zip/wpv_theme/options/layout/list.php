<?php

/**
 * List of options definitions for Theme options / Layout
 *
 * @package wpv
 * @subpackage church-event
 */

return array(
	'general',
	'header',
	'body',
	'footer',
);
