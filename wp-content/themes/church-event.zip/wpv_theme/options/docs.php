



	<div class="container">

<h2><span style="line-height: 1.5;">ALL PRODUCT SUPPORT AND DOCUMENTATION IS ONLINE</span></h2>

Thank you for purchasing our theme!<br/><br/>

Feel free to browse our knowledgebase for videos and extra help<br/>

<b><a href="http://church.support.vamtam.com/support/home" target="_blank">Knowledgebase</a></b><br/>

<b><a href="http://church.support.vamtam.com/solution/categories/2296/folders/268518/articles/200951-how-to-install-the-theme-via-the-admin-panel-" target="_blank">Installation Guide</a></b><br/>

<b><a href="http://church.support.vamtam.com/solution/categories/2296/folders/268518/articles/200952-how-to-update-a-vamtam-theme-and-the-bundled-plugins-" target="_blank">How to Update Guide</a></b><br/>

<b><a href="http://church.support.vamtam.com/solution/categories/2296/folders/264726" target="_blank">Video Guides for Beginners</a></b><br/><br/>



Should you have any queries outside of the scope of the help materials and the video guides don't hesitate to submit a ticket on our secure help desk:<br/>

<b><a href="http://church.support.vamtam.com/support/login" target="_blank">Help Desk Login</a></b><br/><br/>

Please note that you have to sigh up to access the Help Desk. Next step is to verify your purchase.<br/>

Enter your Envato User Name, your Envato API Key and the purchase code in the Theme option panel - general settings - the tab "purchase". We need this information for verification and testing purposes. You need these fields filled in to receive theme and plugins' updates.<br/>

Sorry for any inconveniences!<br/>

If you have difficulties finding the purchase data check out this guide:<br/>

<b><a href="http://church.support.vamtam.com/support/solutions/articles/195536-where-to-get-your-envanto-username-your-envanto-api-key-your-item-purchase-code-from-" target="_blank">Purchase Data</a></b><br/><br/>


if you have installed the theme on a localhost, please provide the Item Purchase Code in addition to entering the purchase data in the Theme option panel - general settings - the tab "purchase".<br/><br/>

Regards,<br/>
VamTam team



	</div><!-- end div .container -->
