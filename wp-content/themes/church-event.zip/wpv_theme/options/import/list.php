<?php
/**
 * List of option definitions for Theme options / Import
 *
 * @package wpv
 * @subpackage church-event
 */

return array(
	'import',
);
