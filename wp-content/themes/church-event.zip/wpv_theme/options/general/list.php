<?php
/**
 * List of option definitions for Theme options / General
 *
 * @package wpv
 * @subpackage church-event
 */

return array(
	'general',
	'posts',
	'single-event',
	'media',
	'purchase',
);
