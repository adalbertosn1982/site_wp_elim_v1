<?php
/**
 * List of option definitions for Theme options / Styles
 *
 * @package wpv
 * @subpackage church-event
 */

return array(
	'global',
	'typography',
	'header',
	'body',
	'footer',
	'skins',
);
