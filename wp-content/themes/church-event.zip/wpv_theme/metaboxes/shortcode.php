<?php
/**
 * TinyMCE-based shortcode generator
 *
 * @package wpv
 * @subpackage church-event
 */

return array(
	'button',
	'dropcap',
	'highlight',
	'icon',
	'inline_divider',
	'lightbox',
	'list',
	'push',
	'tooltip',
);